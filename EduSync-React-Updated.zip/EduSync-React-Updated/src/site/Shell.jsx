import { useEffect, useId, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FlashStack } from "../lib/flash.jsx";
import { siteFlashStore } from "./flash.js";
import { colorFor, currentUser, deleteAccount, initialsFor, logout } from "./core.js";
import { getTheme, setTheme } from "./theme.js";

/* ============================================================
   Shared sidebar / topbar / bottom navigation (was shell.js).
   ============================================================ */

function Icon({ size, children }) {
  return (
    <svg className="icon" width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      {children}
    </svg>
  );
}

const NAV_ITEMS = [
  {
    key: "dashboard", label: "Dashboard", href: "/dashboard.html",
    icon: (<>
      <path d="M3 11l9-8 9 8" />
      <path d="M5 10v10h14V10" />
      <path d="M9 20v-6h6v6" />
    </>)
  },
  {
    key: "subjects", label: "Subjects", href: "/subjects.html",
    icon: (<>
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
    </>)
  },
  {
    key: "assignments", label: "Assignments", href: "/assignments.html",
    icon: (<>
      <path d="M9 11l3 3L22 4" />
      <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
    </>)
  },
  {
    key: "attendance", label: "Attendance", href: "/attendance.html",
    icon: (<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />)
  },
  {
    key: "timetable", label: "Timetable", href: "/timetable.html",
    icon: (<>
      <rect x="3" y="4" width="18" height="17" rx="2" />
      <path d="M16 2v4" />
      <path d="M8 2v4" />
      <path d="M3 10h18" />
      <path d="M8 14h2" />
      <path d="M14 14h2" />
      <path d="M8 18h2" />
      <path d="M14 18h2" />
    </>)
  },
  { key: "focus", label: "Focus Room", href: "/focus-room.html", icon: (<><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>) },
  { key: "achievements", label: "Achievements", href: "/achievements.html", icon: (<><path d="M8 21h8"/><path d="M12 17v4"/><path d="M7 4h10v6a5 5 0 0 1-10 0z"/><path d="M7 7H4v2a4 4 0 0 0 4 4"/><path d="M17 7h3v2a4 4 0 0 1-4 4"/></>) },
  { key: "performance", label: "Academic Performance", href: "/academic-performance.html", icon: (<><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-5 5"/></>) },
  { key: "games", label: "Game Zone", href: "/game-zone.html", icon: (<><path d="M6 12h4m-2-2v4"/><path d="M15 11h.01M18 13h.01"/><rect x="3" y="7" width="18" height="11" rx="3"/><path d="m7 7 1-3h8l1 3"/></>) },
  {
    key: "assistant", label: "AI Assistant", href: "/assistant.html",
    icon: (<>
      <path d="M12 2v4" />
      <path d="M12 18v4" />
      <path d="M4.93 4.93l2.83 2.83" />
      <path d="M16.24 16.24l2.83 2.83" />
      <path d="M2 12h4" />
      <path d="M18 12h4" />
      <path d="M4.93 19.07l2.83-2.83" />
      <path d="M16.24 7.76l2.83-2.83" />
      <circle cx="12" cy="12" r="3" />
    </>),
    ai: true
  }
];

function ProfileChip() {
  const u = currentUser();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const menuId = `profile-menu-${useId()}`;

  useEffect(() => {
    const close = () => setOpen(false);
    document.addEventListener("click", close);
    return () => document.removeEventListener("click", close);
  }, []);

  return (
    <div className="profile-wrap">
      <button type="button" className="profile-chip" id={`profile-chip-${menuId}`}
        aria-haspopup="menu" aria-expanded={open} aria-controls={menuId}
        onClick={(e) => { e.stopPropagation(); setOpen(o => !o); }}>
        <div className="avatar" style={{ background: colorFor(u.email) }}>
          {initialsFor(u.fullName)}
        </div>
        <span className="profile-name">{u.fullName.split(" ")[0]}</span>
      </button>

      <div className={"profile-menu" + (open ? " open" : "")} id={menuId} role="menu">
        <button type="button" role="menuitem" id={`logout-${menuId}`} onClick={() => { logout(); navigate("/login.html"); }}>
          <Icon size={15}>
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
            <polyline points="16 17 21 12 16 7" />
            <line x1="21" y1="12" x2="9" y2="12" />
          </Icon>
          Log out
        </button>

        <button type="button" role="menuitem" id={`delete-${menuId}`} style={{ color: "var(--red)" }}
          onClick={() => {
            if (confirm("Delete your account and all its EduSync data from this device? This can't be undone.")) {
              deleteAccount();
              navigate("/index.html");
            }
          }}>
          <Icon size={15}>
            <path d="M3 6h18" />
            <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
            <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
          </Icon>
          Delete my data
        </button>
      </div>
    </div>
  );
}

/* The page frame: sidebar, topbar (title + profile), flash stack, and
   the mobile bottom nav. Page content goes in as children. */
export function Shell({ active, title, children }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [theme, setCurrentTheme] = useState(getTheme);

  useEffect(() => {
    const updateTheme = event => setCurrentTheme(event.detail);
    window.addEventListener("edusync-theme-change", updateTheme);
    return () => window.removeEventListener("edusync-theme-change", updateTheme);
  }, []);

  function toggleTheme() {
    setCurrentTheme(setTheme(theme === "dark" ? "light" : "dark"));
  }

  function renderNavigation(isDrawer = false) {
    return NAV_ITEMS.map(item => (
      <Link key={item.key} to={item.href} onClick={() => isDrawer && setDrawerOpen(false)}
        className={"nav-link " + (item.ai ? "ai-link " : "") + (item.key === active ? "active" : "")}>
        <Icon size={18}>{item.icon}</Icon>
        <span>{item.label}</span>
      </Link>
    ));
  }

  return (
    <>
      <div className="shell">
        <aside className="sidebar" id="shell-sidebar" aria-label="Main navigation">
          <div className="sidebar-brand">
            <span className="brand-mark">ES</span>
            <span className="brand-name">EduSync</span>
          </div>
          <nav className="sidebar-nav">{renderNavigation()}</nav>
          <div className="sidebar-profile"><ProfileChip /></div>
        </aside>

        <div className="main-column">
          <header className="topbar">
            <div className="topbar-leading">
              <button className="mobile-menu-button" type="button" aria-label="Open navigation menu"
                aria-expanded={drawerOpen} aria-controls="mobile-navigation" onClick={() => setDrawerOpen(true)}>
                <Icon size={20}><path d="M4 6h16M4 12h16M4 18h16" /></Icon>
              </button>
              <div className="topbar-title" id="topbarTitle">{title}</div>
            </div>
            <div className="topbar-actions">
              <button className="theme-toggle" type="button" aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
                aria-pressed={theme === "dark"} onClick={toggleTheme}>
                <Icon size={17}>{theme === "dark" ? <><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/></> : <><path d="M20.9 13A9 9 0 0 1 11 3.1 9 9 0 1 0 20.9 13z"/></>}</Icon>
                <span>{theme === "dark" ? "Dark" : "Light"}</span>
              </button>
              <div className="topbar-profile"><ProfileChip /></div>
            </div>
          </header>
          <main className="content">
            <FlashStack store={siteFlashStore} target="flashStack" className="flash-stack" />
            {children}
          </main>
        </div>
      </div>

      {drawerOpen && <button className="drawer-backdrop" type="button" aria-label="Close navigation menu" onClick={() => setDrawerOpen(false)} />}
      <aside className={"mobile-drawer" + (drawerOpen ? " open" : "")} id="mobile-navigation" aria-label="Mobile navigation" aria-hidden={!drawerOpen} inert={drawerOpen ? undefined : ""}>
        <div className="sidebar-brand"><span className="brand-mark">ES</span><span className="brand-name">EduSync</span>
          <button type="button" className="drawer-close" aria-label="Close navigation menu" onClick={() => setDrawerOpen(false)}>×</button>
        </div>
        <nav className="sidebar-nav">{renderNavigation(true)}</nav>
        <ProfileChip />
      </aside>
    </>
  );
}
