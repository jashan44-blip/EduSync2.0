export const THEME_KEY = "edusync_theme";

export function getTheme() {
  try {
    return localStorage.getItem(THEME_KEY) === "dark" ? "dark" : "light";
  } catch (error) {
    console.warn("EduSync: couldn't read the saved theme preference.", error);
    return document.documentElement.dataset.theme === "dark" ? "dark" : "light";
  }
}

export function setTheme(theme) {
  const nextTheme = theme === "dark" ? "dark" : "light";
  document.documentElement.dataset.theme = nextTheme;
  document.documentElement.style.colorScheme = nextTheme;
  const themeColor = document.querySelector('meta[name="theme-color"]');
  if (themeColor) themeColor.content = nextTheme === "dark" ? "#0d1728" : "#f4f7fb";
  try {
    localStorage.setItem(THEME_KEY, nextTheme);
  } catch (error) {
    console.warn("EduSync: couldn't save the theme preference.", error);
  }
  window.dispatchEvent(new CustomEvent("edusync-theme-change", { detail: nextTheme }));
  return nextTheme;
}
