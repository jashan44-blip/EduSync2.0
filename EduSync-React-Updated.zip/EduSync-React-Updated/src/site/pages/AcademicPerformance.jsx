import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Shell } from "../Shell.jsx";
import { usePage } from "../SiteLayout.jsx";
import { currentUserData, saveApp, subjectAttendance, uid } from "../core.js";
import { flash } from "../flash.js";

const dateKey = (date = new Date()) => {
  const value = new Date(date);
  return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}-${String(value.getDate()).padStart(2, "0")}`;
};
const numericMark = value => value !== "" && value !== null && value !== undefined && Number.isFinite(Number(value)) ? Number(value) : null;

export default function AcademicPerformance() {
  usePage("Academic Performance — EduSync", "academic-performance");
  const D = currentUserData();
  const [subjectFilter, setSubjectFilter] = useState("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [refresh, setRefresh] = useState(0);
  const marks = D.subjects.map(subject => ({ subject, value: numericMark(subject.marks) })).filter(item => item.value !== null);
  const attendance = D.subjects.map(subject => ({ subject, ...subjectAttendance(subject.id) }));
  const visibleMarks = marks.filter(item => subjectFilter === "all" || item.subject.id === subjectFilter);
  const visibleAttendance = attendance.filter(item => item.pct !== null && (subjectFilter === "all" || item.subject.id === subjectFilter));
  const completed = D.assignments.filter(item => item.status === "completed").length;
  const pending = D.assignments.length - completed;
  const averageMark = marks.length ? marks.reduce((sum, item) => sum + item.value, 0) / marks.length : null;
  const attendanceValues = attendance.filter(item => item.pct !== null).map(item => item.pct);
  const averageAttendance = attendanceValues.length ? attendanceValues.reduce((sum, value) => sum + value, 0) / attendanceValues.length : null;
  const assignmentProgress = D.assignments.length ? Math.round((completed / D.assignments.length) * 100) : null;

  const history = useMemo(() => (D.markHistory || []).map(record => ({
    ...record,
    value: numericMark(record.marks ?? record.score)
  })).filter(record => record.value !== null && (!subjectFilter || subjectFilter === "all" || record.subjectId === subjectFilter)
    && (!fromDate || record.date >= fromDate) && (!toDate || record.date <= toDate)
  ).sort((a, b) => a.date.localeCompare(b.date)), [D.markHistory, subjectFilter, fromDate, toDate, refresh]);

  function recordSnapshot() {
    const today = dateKey();
    const subjectsWithMarks = marks.filter(item => !D.markHistory.some(record => record.subjectId === item.subject.id && record.date === today));
    if (!subjectsWithMarks.length) {
      flash(marks.length ? "Today's marks are already recorded." : "Add marks to a subject before recording a snapshot.", "error");
      return;
    }
    D.markHistory = D.markHistory || [];
    subjectsWithMarks.forEach(({ subject, value }) => D.markHistory.push({
      id: uid(), subjectId: subject.id, date: today, marks: value
    }));
    saveApp();
    setRefresh(value => value + 1);
    flash(`Recorded marks for ${subjectsWithMarks.length} subject${subjectsWithMarks.length === 1 ? "" : "s"}.`, "success");
  }

  const trendDates = [...new Set(history.map(record => record.date))];
  const trendPoints = history.map(record => {
    const x = trendDates.length === 1 ? 50 : (trendDates.indexOf(record.date) / (trendDates.length - 1)) * 100;
    const y = 100 - record.value;
    const subject = D.subjects.find(item => item.id === record.subjectId);
    return { ...record, x, y, label: subject?.name || "Subject" };
  });
  const trendSeries = Object.values(trendPoints.reduce((series, point) => {
    series[point.subjectId] = series[point.subjectId] || [];
    series[point.subjectId].push(point);
    return series;
  }, {}));

  return <Shell active="performance" title="Academic Performance">
    <div className="focus-head">
      <div><p className="eyebrow">YOUR ACADEMIC DATA</p><h1>Performance, at a glance.</h1><p className="muted-copy">Charts reflect the marks, attendance, and assignments saved to your account.</p></div>
      <button className="btn btn-primary btn-sm" type="button" onClick={recordSnapshot}>Record current marks</button>
    </div>

    <div className="performance-summary">
      <div className="card performance-stat"><span>Average available marks</span><strong>{averageMark === null ? "—" : `${averageMark.toFixed(1)}%`}</strong><small>{marks.length ? `${marks.length} of ${D.subjects.length} subjects have marks` : "Add marks in your Subjects page"}</small></div>
      <div className="card performance-stat"><span>Average attendance</span><strong>{averageAttendance === null ? "—" : `${averageAttendance.toFixed(1)}%`}</strong><small>{attendanceValues.length ? `${attendanceValues.length} subjects with attendance records` : "No attendance records yet"}</small></div>
      <div className="card performance-stat"><span>Assignment completion</span><strong>{assignmentProgress === null ? "—" : `${assignmentProgress}%`}</strong><small>{completed} completed · {pending} pending</small></div>
    </div>

    <div className="performance-filter card">
      <div><p className="eyebrow">FILTER DATA</p><strong>Choose what to compare</strong></div>
      <label>Subject
        <select value={subjectFilter} onChange={event => setSubjectFilter(event.target.value)}>
          <option value="all">All subjects</option>
          {D.subjects.map(subject => <option value={subject.id} key={subject.id}>{subject.name}</option>)}
        </select>
      </label>
      <label>From date<input type="date" value={fromDate} onChange={event => setFromDate(event.target.value)} /></label>
      <label>To date<input type="date" value={toDate} onChange={event => setToDate(event.target.value)} /></label>
    </div>

    <div className="performance-grid">
      <section className="card chart-card">
        <div className="card-heading"><div><p className="eyebrow">CURRENT MARKS</p><h2>Subject-wise marks</h2></div><span className="chart-legend"><i className="legend-dot marks-dot" />Marks (%)</span></div>
        {!visibleMarks.length ? <div className="empty-state compact">{marks.length ? "No marks are available for this subject." : <>No marks have been entered yet. Add actual marks on the <Link className="auth-link" to="/subjects.html">Subjects page</Link> to see a comparison.</>}</div> :
          <div className="horizontal-bars" role="img" aria-label="Subject marks compared as percentages">
            {visibleMarks.map(({ subject, value }) => <div className="horizontal-bar-row" key={subject.id}>
              <span title={subject.name}>{subject.name}</span><div className="horizontal-bar-track"><i style={{ width: `${Math.min(100, Math.max(0, value))}%` }} /></div><strong>{value}%</strong>
            </div>)}
          </div>}
      </section>

      <section className="card chart-card">
        <div className="card-heading"><div><p className="eyebrow">RECORDED OVER TIME</p><h2>Performance trend</h2></div><span className="chart-legend"><i className="legend-dot trend-dot" />Marks snapshots</span></div>
        {!trendPoints.length ? <div className="empty-state compact">No dated mark snapshots yet. When you record marks, the trend will use those real dates and scores.</div> :
          <><div className="trend-chart">
            <div className="trend-axis"><span>100%</span><span>50%</span><span>0%</span></div>
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" role="img" aria-label="Marks over time">
              <line x1="0" y1="0" x2="100" y2="0" className="chart-gridline" />
              <line x1="0" y1="50" x2="100" y2="50" className="chart-gridline" />
              <line x1="0" y1="100" x2="100" y2="100" className="chart-gridline" />
              {trendSeries.map(series => series.length > 1 && <polyline key={series[0].subjectId} points={series.map(point => `${point.x},${point.y}`).join(" ")} className="trend-line" style={{ stroke: D.subjects.find(subject => subject.id === series[0].subjectId)?.color || undefined }} />)}
              {trendPoints.map(point => <circle key={point.id || `${point.subjectId}-${point.date}`} cx={point.x} cy={point.y} r="1.6" className="trend-point">
                <title>{`${point.label}: ${point.value}% on ${point.date}`}</title>
              </circle>)}
            </svg>
          </div><div className="trend-dates"><span>{trendDates[0]}</span>{trendDates.length > 1 && <span>{trendDates[trendDates.length - 1]}</span>}</div>
          {trendSeries.length > 1 && <div className="trend-series-legend">{trendSeries.map(series => {
            const subject = D.subjects.find(item => item.id === series[0].subjectId);
            return <span key={series[0].subjectId}><i style={{ background: subject?.color || "var(--violet)" }} />{subject?.name || "Subject"}</span>;
          })}</div>}
          {trendDates.length < 2 && <p className="muted-copy chart-note">Record another mark snapshot on a later date to see a trend line.</p>}</>}
      </section>

      <section className="card chart-card">
        <div className="card-heading"><div><p className="eyebrow">ATTENDANCE RECORDS</p><h2>Attendance by subject</h2></div><span className="chart-legend"><i className="legend-dot attendance-dot" />Present (%)</span></div>
        {!visibleAttendance.length ? <div className="empty-state compact">{attendanceValues.length ? "No attendance records are available for this subject." : <>No attendance records yet. Attendance percentages appear after you mark classes on the <Link className="auth-link" to="/attendance.html">Attendance page</Link>.</>}</div> :
          <div className="horizontal-bars" role="img" aria-label="Attendance percentage by subject">
            {visibleAttendance.map(({ subject, pct, held }) => <div className="horizontal-bar-row" key={subject.id}>
              <span title={subject.name}>{subject.name}</span><div className="horizontal-bar-track" title={`${subject.name}: ${pct}% attendance from ${held} class${held === 1 ? "" : "es"}`}><i className="attendance-bar" style={{ width: `${Math.min(100, Math.max(0, pct))}%` }} /></div><strong>{pct}% <small>({held})</small></strong>
            </div>)}
          </div>}
      </section>

      <section className="card chart-card">
        <div className="card-heading"><div><p className="eyebrow">ASSIGNMENT TRACKER</p><h2>Completed vs pending</h2></div></div>
        {!D.assignments.length ? <div className="empty-state compact">No assignments saved yet. Add assignments to track completion progress.</div> :
          <div className="assignment-chart">
            <div className="assignment-chart-labels"><span>Completed <strong>{completed}</strong></span><span>Pending <strong>{pending}</strong></span></div>
            <div className="assignment-stacked" role="img" aria-label={`${completed} completed and ${pending} pending assignments`} title={`${completed} completed · ${pending} pending`}>
              <i className="completed-segment" style={{ width: `${(completed / D.assignments.length) * 100}%` }} />
              <i className="pending-segment" style={{ width: `${(pending / D.assignments.length) * 100}%` }} />
            </div>
            <p className="muted-copy">{completed} of {D.assignments.length} assignments completed ({assignmentProgress}%).</p>
          </div>}
      </section>
    </div>
  </Shell>;
}
