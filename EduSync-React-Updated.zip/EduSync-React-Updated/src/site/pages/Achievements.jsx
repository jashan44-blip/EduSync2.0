import { Link } from "react-router-dom";
import { useEffect } from "react";
import { Shell } from "../Shell.jsx";
import { usePage } from "../SiteLayout.jsx";
import { currentUserData, saveApp } from "../core.js";
import { consumeBadgeNotifications, getGamificationStats } from "../gamification.js";
import { flash } from "../flash.js";
export default function Achievements(){
 usePage("Achievements — EduSync","achievements");
 const D=currentUserData(); const stats=getGamificationStats(D);
 useEffect(()=>{const unlocked=consumeBadgeNotifications(D);if(unlocked.length){saveApp();flash(`Achievement unlocked: ${unlocked.join(", ")}!`,"success");}},[D]);
 const weekStart=(()=>{const d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()-((d.getDay()+6)%7));return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;})();
 const weekSessions=(D.focusSessions||[]).filter(s=>s.completed&&s.date>=weekStart);
 const weekMinutes=weekSessions.reduce((n,s)=>n+s.durationMinutes,0);
 const activeDays=new Set(weekSessions.map(s=>s.date)).size;
 const milestones=[{title:"Five focus sessions",detail:"Complete 5 sessions this week",value:weekSessions.length,target:5},{title:"Study for 3 hours",detail:"Reach 180 focused minutes this week",value:weekMinutes,target:180},{title:"Show up on 3 days",detail:"Study on 3 different days this week",value:activeDays,target:3}];
 const subjectMinutes={};(D.focusSessions||[]).filter(s=>s.completed&&s.subjectId).forEach(s=>{subjectMinutes[s.subjectId]=(subjectMinutes[s.subjectId]||0)+s.durationMinutes;});
 const bestSubject=Object.entries(subjectMinutes).sort((a,b)=>b[1]-a[1])[0];
 const highestDay=Object.entries((D.focusSessions||[]).filter(s=>s.completed).reduce((a,s)=>{a[s.date]=(a[s.date]||0)+s.durationMinutes;return a;},{})).sort((a,b)=>b[1]-a[1])[0];
 return <Shell active="achievements" title="Achievements"><div className="focus-head"><div><p className="eyebrow">YOUR PROGRESS</p><h1>Small wins. Real momentum.</h1><p className="muted-copy">Every stat is based on your completed activity — no made-up milestones.</p></div><Link className="btn btn-primary btn-sm" to="/focus-room.html">Open Focus Room ↗</Link></div>
 <div className="achievement-metrics"><div className="card"><span>⚡ Total XP</span><strong>{D.xp||0}</strong><small>earned XP</small></div><div className="card"><span>🔥 Current streak</span><strong>{stats.currentStreak}</strong><small>consecutive study days</small></div><div className="card"><span>🏆 Best streak</span><strong>{Math.max(D.bestStudyStreak||0,stats.bestStreak)}</strong><small>days in a row</small></div><div className="card"><span>⏱️ Focus sessions</span><strong>{stats.sessions}</strong><small>{stats.minutes} total focused minutes</small></div></div>
 <section className="card achievement-section"><div className="card-heading"><div><p className="eyebrow">UNLOCKS</p><h2>Achievement badges</h2></div><span className="muted-copy">{stats.badges.filter(b=>b.unlocked).length} / {stats.badges.length} unlocked</span></div><div className="badge-grid">{stats.badges.map(b=><article className={"badge-card "+(b.unlocked?"unlocked":"locked")} key={b.id}><div className="badge-icon">{b.icon}</div><div className="badge-status">{b.unlocked?"UNLOCKED":"LOCKED"}</div><h3>{b.name}</h3><p>{b.description}</p><div className="goal-track"><span style={{width:`${b.progress}%`}}/></div><small>{Math.min(b.value,b.target)} / {b.target} {b.id==="hour"?"minutes":b.id==="roll"||b.id==="consistency"?"days":b.id==="task"?"assignments":"completed"}</small></article>)}</div></section>
 <section className="card achievement-section"><div className="card-heading"><div><p className="eyebrow">THIS WEEK</p><h2>Weekly milestones</h2></div><span className="muted-copy">Monday–Sunday</span></div><div className="milestone-list">{milestones.map(m=><div className="milestone-row" key={m.title}><div className="milestone-symbol">{m.value>=m.target?"✓":"↗"}</div><div className="milestone-main"><strong>{m.title}</strong><small>{m.detail}</small><div className="goal-track"><span style={{width:`${Math.min(100,m.value/m.target*100)}%`}}/></div></div><b>{Math.min(m.value,m.target)} / {m.target}</b></div>)}</div></section>
 <section className="card achievement-section"><div className="card-heading"><div><p className="eyebrow">PERSONAL RECORDS</p><h2>Your bests</h2></div></div><div className="record-grid"><div><span>Most productive subject</span><strong>{bestSubject?D.subjects.find(s=>s.id===bestSubject[0])?.name||"Subject": "Not enough data"}</strong>{bestSubject&&<small>{bestSubject[1]} focused minutes</small>}</div><div><span>Highest-focus day</span><strong>{highestDay?new Date(highestDay[0]+"T12:00:00").toLocaleDateString(undefined,{weekday:"short",day:"numeric",month:"short"}):"Not enough data"}</strong>{highestDay&&<small>{highestDay[1]} focused minutes</small>}</div><div><span>Completed assignments</span><strong>{stats.assignments}</strong><small>from your assignment list</small></div><div><span>Study days recorded</span><strong>{stats.studyDays.length}</strong><small>unique calendar days</small></div></div></section>
 </Shell>;
}
