import { Link } from "react-router-dom";
import { useEffect, useReducer } from "react";
import { Shell } from "../Shell.jsx";
import { usePage } from "../SiteLayout.jsx";
import { flash } from "../flash.js";
import {
  THRESHOLD, assignmentBucket, currentUser, currentUserData, fmtDateTime,
  generateInsights, nextBestAction, saveApp, subjectAttendance, uid
} from "../core.js";
import { AssignmentModal, SubjectModal, readAssignmentForm, readSubjectForm, useModal } from "../Modals.jsx";
import { consumeBadgeNotifications, getGamificationStats } from "../gamification.js";
import { setTheme } from "../theme.js";

export default function Dashboard() {
  usePage("Dashboard — EduSync", "dashboard");
  const [renderKey, renderDashboard] = useReducer(k => k + 1, 0);
  const subjectModal = useModal();
  const assignmentModal = useModal();

  const u = currentUser(); const D = currentUserData();
  const gameStats = getGamificationStats(D);
  const markValues = D.subjects.map(subject => subject.marks).filter(value => value !== "" && value !== null && value !== undefined && Number.isFinite(Number(value))).map(Number);
  const averageMarks = markValues.length ? (markValues.reduce((sum, value) => sum + value, 0) / markValues.length).toFixed(1) : null;
  const recentBadges = gameStats.badges.filter(badge => badge.unlocked).slice(-2).reverse();
  useEffect(() => {
    const unlocked = consumeBadgeNotifications(D);
    if (unlocked.length) {
      saveApp();
      flash(`Achievement unlocked: ${unlocked.join(", ")}!`, "success");
    }
  }, [D]);
  const now = new Date(); const todayFocusKey = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}-${String(now.getDate()).padStart(2,"0")}`;
  const todayFocusMinutes = (D.focusSessions || []).filter(s => s.completed && s.date === todayFocusKey).reduce((n,s)=>n+s.durationMinutes,0);
  const pending = D.assignments.filter(a => a.status === "pending");
  const overdue = pending.filter(a => assignmentBucket(a) === "overdue").length;
  const attendances = D.subjects.map(s => subjectAttendance(s.id).pct).filter(p => p !== null);
  const avgAttendance = attendances.length ? Math.round((attendances.reduce((a, b) => a + b, 0) / attendances.length) * 10) / 10 : null;

  const alerts = [];
  D.subjects.forEach(s => {
    const { pct } = subjectAttendance(s.id);
    if (pct !== null && pct < THRESHOLD) alerts.push(`🔴 ${s.name} attendance is ${pct}% — below the ${THRESHOLD}% requirement.`);
  });
  pending.forEach(a => {
    const deadline = new Date(a.deadline);
    if (deadline < new Date()) alerts.push(`⚠️ '${a.title}' is overdue.`);
    else if (deadline - new Date() < 1000 * 60 * 60 * 24) alerts.push(`🟠 '${a.title}' is due tomorrow.`);
  });

  const rec = nextBestAction();
  const insights = generateInsights();
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const upcoming = [...pending].sort((a, b) => new Date(a.deadline) - new Date(b.deadline)).slice(0, 5);

  function openSubjectModal() { subjectModal.openWith(); }
  function openAssignmentModal() {
    if (!D.subjects.length) { flash("Add a subject first.", "error"); return; }
    assignmentModal.openWith();
  }

  function onSubjectSubmit(e) {
    e.preventDefault();
    const { payload } = readSubjectForm(e.currentTarget);
    D.subjects.push({ id: uid(), ...payload });
    saveApp();
    subjectModal.close();
    flash("Subject added.", "success");
    renderDashboard();
  }

  function onAssignmentSubmit(e) {
    e.preventDefault();
    const { payload } = readAssignmentForm(e.currentTarget);
    D.assignments.push({ id: uid(), status: "pending", completedAt: null, ...payload });
    saveApp();
    assignmentModal.close();
    flash("Assignment added.", "success");
    renderDashboard();
  }

  let recCard = null;
  if (rec) {
    const pct = Math.min(rec.score, 100);
    const circumference = 251.2;
    const offset = circumference * (1 - pct / 100);
    recCard = (
      <div className="card action-card tilt" style={{ marginBottom: "24px" }}>
        <svg width="96" height="96" viewBox="0 0 96 96">
          <circle cx="48" cy="48" r="40" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="9" />
          <circle cx="48" cy="48" r="40" fill="none" stroke="var(--primary)" strokeWidth="9" strokeLinecap="round"
            strokeDasharray={circumference} strokeDashoffset={offset} transform="rotate(-90 48 48)" />
          <text x="48" y="53" textAnchor="middle" fontFamily="IBM Plex Mono, monospace" fontSize="18" fontWeight="600" fill="var(--ink)">{Math.floor(rec.score)}</text>
        </svg>
        <div className="action-body">
          <div className="action-eyebrow">🎯 Your next best action</div>
          <div className="action-title">Study {rec.subject.name} — {rec.a.title} for {rec.duration} minutes</div>
          <div className="action-reason">Because {rec.reason}.</div>
          <Link className="btn btn-primary btn-sm magnetic" to="/assignments.html">View assignment</Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <Shell active="dashboard" title="Dashboard">
        <div id="pageRoot" key={renderKey}>
          <h1 style={{ fontSize: "24px", marginBottom: "2px" }}>{greeting}, {u.fullName.split(" ")[0]} 👋</h1>
          <p style={{ color: "var(--muted)", marginBottom: "24px" }}>Here's where things stand today.</p>
          <div className="dashboard-focus-strip">
            <Link to="/focus-room.html" className="card dash-focus-card"><span>◷</span><div><small>Today's focus</small><strong>{todayFocusMinutes} min</strong><em>Open Focus Room ↗</em></div></Link>
            <Link to="/achievements.html" className="card dash-focus-card"><span>🔥</span><div><small>Study streak</small><strong>{gameStats.currentStreak} day{gameStats.currentStreak===1?"":"s"}</strong><em>Keep your momentum</em></div></Link>
            <Link to="/achievements.html" className="card dash-focus-card"><span>⚡</span><div><small>Total XP</small><strong>{D.xp||0} XP</strong><em>{gameStats.badges.filter(b=>b.unlocked).length} badges unlocked ↗</em></div></Link>
            <Link to="/focus-room.html" className="card dash-focus-card"><span>🎯</span><div><small>Daily goal</small><strong>{Math.min(100,Math.round(todayFocusMinutes/(D.focusGoalMinutes||60)*100))}%</strong><em>{Math.max(0,(D.focusGoalMinutes||60)-todayFocusMinutes)} min remaining</em></div></Link>
          </div>
          <div className="dashboard-extras">
            <Link to="/academic-performance.html" className="card dashboard-extra-card"><span className="extra-icon">📊</span><div><small>Academic performance</small><strong>{averageMarks === null ? "No marks yet" : `${averageMarks}% average`}</strong><em>{D.assignments.filter(item => item.status === "completed").length} assignments completed · view analysis ↗</em></div></Link>
            <Link to="/game-zone.html" className="card dashboard-extra-card"><span className="extra-icon">🎮</span><div><small>Game Zone</small><strong>{D.gameAttempts.length} {D.gameAttempts.length === 1 ? "quiz" : "quizzes"} completed</strong><em>Try a daily challenge ↗</em></div></Link>
            <Link to="/achievements.html" className="card dashboard-extra-card"><span className="extra-icon">🏅</span><div><small>Recently earned</small><strong>{recentBadges.length ? recentBadges.map(badge => badge.name).join(" · ") : "Your next milestone awaits"}</strong><em>{gameStats.badges.filter(badge => badge.unlocked).length} achievements unlocked ↗</em></div></Link>
          </div>
          <section className="theme-preview-section">
            <div className="card-heading"><div><p className="eyebrow">PERSONALIZE YOUR SPACE</p><h2>Light and dark previews</h2></div></div>
            <div className="theme-preview-grid">
              {["light", "dark"].map(theme => <button className="theme-preview-card" data-theme={theme} key={theme} type="button" onClick={() => setTheme(theme)} aria-label={`Apply ${theme} theme preview`}>
                <span className="preview-toolbar"><i /><i /><i /><b>EduSync dashboard</b></span>
                <span className="preview-content"><span className="preview-sidebar"><i /><i /><i /></span><span className="preview-main"><b>Good {greeting.toLowerCase().replace("good ", "")}, {u.fullName.split(" ")[0]}</b><span className="preview-metrics"><i /><i /><i /></span><span className="preview-chart"><i /></span></span></span>
                <span className="preview-caption">{theme === "light" ? "☀ Light mode" : "☾ Dark mode"} <em>Click to apply</em></span>
              </button>)}
            </div>
          </section>
          <div className="grid grid-4" style={{ marginBottom: "24px" }}>
            <div className="card metric-tile tilt"><div className="metric-top"><span className="metric-label">Avg. Attendance</span><span className="metric-icon" style={{ background: "var(--green-tint)" }}>🛡️</span></div><div className={"metric-value " + (avgAttendance !== null && avgAttendance < 75 ? "danger" : "good")}>{avgAttendance !== null ? avgAttendance + "%" : "—"}</div></div>
            <div className="card metric-tile tilt"><div className="metric-top"><span className="metric-label">Pending</span><span className="metric-icon" style={{ background: "var(--primary-tint)" }}>📋</span></div><div className="metric-value">{pending.length}</div></div>
            <div className="card metric-tile tilt"><div className="metric-top"><span className="metric-label">Overdue</span><span className="metric-icon" style={{ background: "var(--red-tint)" }}>⚠️</span></div><div className={"metric-value " + (overdue > 0 ? "danger" : "")}>{overdue}</div></div>
            <div className="card metric-tile tilt"><div className="metric-top"><span className="metric-label">XP</span><span className="metric-icon" style={{ background: "var(--amber-tint)" }}>⭐</span></div><div className="metric-value">{D.xp}</div></div>
          </div>
          {recCard}
          <div className="card insights-card tilt" style={{ marginBottom: "24px" }}>
            <div className="card-title" style={{ display: "flex", alignItems: "center", gap: "8px" }}>✨ AI Insights <span className="badge badge-ai">local · rule-based</span></div>
            {insights.map((i, idx) => (
              <div className="insight-row" key={idx}><span className="insight-dot"></span><span dangerouslySetInnerHTML={{ __html: i }} /></div>
            ))}
          </div>
          {alerts.length > 0 && (
            <div className="card" style={{ marginBottom: "24px" }}>
              <div className="card-title">Academic alerts</div>
              {alerts.map((a, idx) => (
                <div key={idx} style={{ padding: "8px 0", borderBottom: "1px solid var(--border)", fontSize: "13.5px" }}>{a}</div>
              ))}
            </div>
          )}
          <div className="card" style={{ marginBottom: "24px" }}>
            <div className="card-title">Upcoming</div>
            {upcoming.length ? upcoming.map(a => {
              const subject = D.subjects.find(s => s.id === a.subjectId);
              const bucket = assignmentBucket(a);
              const badgeClass = bucket === "overdue" ? "badge-danger" : (bucket === "due_today" || bucket === "due_soon") ? "badge-warn" : "badge-neutral";
              return (
                <div className="assignment-row" key={a.id}>
                  <div className="assignment-info">
                    <div className="assignment-title">{a.title}</div>
                    <div className="assignment-meta">{subject ? subject.name : ""} · <span className="mono">{fmtDateTime(a.deadline)}</span></div>
                  </div>
                  <span className={"badge " + badgeClass}>{bucket.replace("_", " ")}</span>
                </div>
              );
            }) : (
              <div className="empty-state"><div className="empty-glyph">🎯</div>You're all caught up. No pending assignments.</div>
            )}
          </div>
          <div className="card-title" style={{ marginBottom: "10px" }}>Quick actions</div>
          <div className="btn-row">
            <button className="btn btn-primary btn-sm magnetic" id="qaAddAssignment" onClick={openAssignmentModal}>Add Assignment</button>
            <button className="btn btn-ghost btn-sm magnetic" id="qaAddSubject" onClick={openSubjectModal}>Add Subject</button>
            <Link className="btn btn-ai btn-sm magnetic" to="/assistant.html">✨ Ask AI Assistant</Link>
          </div>
        </div>
      </Shell>

      <SubjectModal open={subjectModal.open} formKey={subjectModal.key} title="Add Subject"
        onClose={subjectModal.close} onSubmit={onSubjectSubmit} />
      <AssignmentModal open={assignmentModal.open} formKey={assignmentModal.key} title="Add Assignment"
        subjects={D.subjects} onClose={assignmentModal.close} onSubmit={onAssignmentSubmit} />
    </>
  );
}
