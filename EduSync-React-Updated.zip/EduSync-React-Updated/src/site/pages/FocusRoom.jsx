import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Shell } from "../Shell.jsx";
import { usePage } from "../SiteLayout.jsx";
import { currentUserData, saveApp, uid } from "../core.js";
import { flash } from "../flash.js";
import { recordFocusCompletion, getGamificationStats } from "../gamification.js";

const todayKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const fmt = s => `${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;
export default function FocusRoom() {
  usePage("Focus Room — EduSync", "focus-room");
  const D = currentUserData();
  const [tick, setTick] = useState(Date.now());
  const [mode, setMode] = useState("focus");
  const [focusMins, setFocusMins] = useState(25);
  const [breakMins, setBreakMins] = useState(5);
  const [subjectId, setSubjectId] = useState("");
  const [running, setRunning] = useState(false);
  const [endAt, setEndAt] = useState(null);
  const [remaining, setRemaining] = useState(25*60);
  const [goal, setGoal] = useState(() => D.focusGoalMinutes || 60);
  const [refresh, setRefresh] = useState(0);
  const finishedRef = useRef(false);
  const sessions = D.focusSessions || [];
  const today = todayKey();
  const todaySessions = sessions.filter(s => s.date === today && s.completed);
  const todayMinutes = todaySessions.reduce((n,s)=>n+s.durationMinutes,0);
  const weekly = useMemo(()=>Array.from({length:7},(_,i)=>{const d=new Date(); d.setHours(0,0,0,0); d.setDate(d.getDate()-6+i); const key=todayKey(d); return {key,label:d.toLocaleDateString(undefined,{weekday:"short"}),minutes:sessions.filter(s=>s.date===key&&s.completed).reduce((n,s)=>n+s.durationMinutes,0)};}),[sessions,refresh]);
  const totalWeek = weekly.reduce((n,d)=>n+d.minutes,0);
  const seconds = running && endAt ? Math.max(0,Math.ceil((endAt-tick)/1000)) : remaining;
  useEffect(()=>{ if(!running) return; const id=setInterval(()=>setTick(Date.now()),250); return ()=>clearInterval(id); },[running]);
  useEffect(()=>{
    if(running && endAt && tick>=endAt && !finishedRef.current){
      finishedRef.current=true; setRunning(false); setRemaining(0);
      if(mode==="focus") completeSession(); else { flash("Break complete — ready to focus again?","success"); setMode("focus"); setRemaining(focusMins*60); }
    }
  },[tick,running,endAt,mode]);
  function completeSession(){
    if(finishedRef.current && seconds>0) return;
    const mins = mode==="focus" ? focusMins : 0;
    if(!mins) return;
    const record={id:uid(),date:todayKey(),completedAt:new Date().toISOString(),subjectId:subjectId||null,durationMinutes:mins,completed:true,xpAwarded:10};
    D.focusSessions=D.focusSessions||[];
    if(!D.focusSessions.some(s=>s.id===record.id)) D.focusSessions.push(record);
    const unlocked = recordFocusCompletion(D, record);
    saveApp(); setRefresh(x=>x+1); flash(`Focus session completed. +10 XP${subjectId?" and progress saved":""}!`,"success");
    if (unlocked.length) flash(`Achievement unlocked: ${unlocked.join(", ")}!`, "success");
  }
  function start(){ if(seconds<=0) setRemaining((mode==="focus"?focusMins:breakMins)*60); finishedRef.current=false; const base=seconds>0?seconds:(mode==="focus"?focusMins:breakMins)*60; setEndAt(Date.now()+base*1000); setTick(Date.now()); setRunning(true); }
  function pause(){ setRemaining(seconds); setRunning(false); setEndAt(null); }
  function reset(){ setRunning(false); setEndAt(null); finishedRef.current=false; setRemaining((mode==="focus"?focusMins:breakMins)*60); }
  function switchMode(next){setMode(next);setRunning(false);setEndAt(null);finishedRef.current=false;setRemaining((next==="focus"?focusMins:breakMins)*60);}
  function saveGoal(){D.focusGoalMinutes=Math.max(5,Number(goal)||60);saveApp();setGoal(D.focusGoalMinutes);setRefresh(x=>x+1);flash("Daily focus goal saved.","success");}
  const maxBar=Math.max(1,...weekly.map(d=>d.minutes));
  const stats=getGamificationStats(D);
  const circumference=2*Math.PI*82;
  const progress=1-Math.min(1,seconds/Math.max(1,(mode==="focus"?focusMins:breakMins)*60));
  return <Shell active="focus" title="Focus Room">
    <div className="focus-head"><div><p className="eyebrow">STUDY MODE</p><h1>Make time count.</h1><p className="muted-copy">One focused session at a time. Your progress is saved automatically.</p></div><Link className="btn btn-ghost btn-sm" to="/achievements.html">View achievements ↗</Link></div>
    <div className="focus-layout">
      <section className="card focus-timer-card">
        <div className="mode-tabs"><button className={mode==="focus"?"selected":""} onClick={()=>switchMode("focus")}>Focus</button><button className={mode==="break"?"selected":""} onClick={()=>switchMode("break")}>Break</button></div>
        <div className="timer-ring"><svg viewBox="0 0 190 190" aria-label="Timer progress"><circle cx="95" cy="95" r="82" className="timer-track"/><circle cx="95" cy="95" r="82" className="timer-progress" strokeDasharray={circumference} strokeDashoffset={circumference*progress}/></svg><div className="timer-readout"><strong>{fmt(seconds)}</strong><span>{running?"STAY IN THE ZONE":seconds===0?"SESSION COMPLETE":mode==="focus"?"READY TO FOCUS":"TAKE A BREATH"}</span></div></div>
        <label className="field-label">Study subject</label><select value={subjectId} onChange={e=>setSubjectId(e.target.value)} disabled={running}><option value="">General study session</option>{D.subjects.map(s=><option key={s.id} value={s.id}>{s.code ? `${s.code} — `:""}{s.name}</option>)}</select>
        <div className="timer-controls">{!running?<button className="btn btn-primary" onClick={start}>{seconds===0?"Start again":seconds<(mode==="focus"?focusMins:breakMins)*60?"Resume":"Start session"}</button>:<button className="btn btn-primary" onClick={pause}>Pause</button>}<button className="btn btn-ghost" onClick={reset}>Reset</button></div>
        <div className="duration-settings"><label>Focus (min)<input type="number" min="1" max="180" value={focusMins} disabled={running} onChange={e=>{const n=Math.min(180,Math.max(1,Number(e.target.value)||1));setFocusMins(n);if(mode==="focus")setRemaining(n*60);}}/></label><label>Break (min)<input type="number" min="1" max="60" value={breakMins} disabled={running} onChange={e=>{const n=Math.min(60,Math.max(1,Number(e.target.value)||1));setBreakMins(n);if(mode==="break")setRemaining(n*60);}}/></label></div>
      </section>
      <div className="focus-side">
        <section className="card goal-card"><div className="card-heading"><div><p className="eyebrow">TODAY'S GOAL</p><h2>{todayMinutes} <small>/ {D.focusGoalMinutes||60} min</small></h2></div><span className="focus-emoji">🎯</span></div><div className="goal-track"><span style={{width:`${Math.min(100,todayMinutes/(D.focusGoalMinutes||60)*100)}%`}}/></div><p className="muted-copy">{Math.max(0,(D.focusGoalMinutes||60)-todayMinutes)} minutes left · {todaySessions.length} completed session{todaySessions.length===1?"":"s"}</p><div className="goal-edit"><label>Daily target (minutes)<input type="number" min="5" max="1440" value={goal} onChange={e=>setGoal(e.target.value)}/></label><button className="btn btn-ghost btn-sm" onClick={saveGoal}>Save goal</button></div></section>
        <section className="card mini-stat-grid"><div><span>Current streak</span><strong>🔥 {stats.currentStreak} days</strong></div><div><span>Total XP</span><strong>⚡ {D.xp||0} XP</strong></div></section>
        <section className="card"><div className="card-heading"><div><p className="eyebrow">LAST 7 DAYS</p><h2>{Math.floor(totalWeek/60)}h {totalWeek%60}m focused</h2></div></div><div className="week-bars">{weekly.map(d=><div className="week-bar" key={d.key}><div className="week-bar-track"><span style={{height:`${d.minutes?Math.max(5,d.minutes/maxBar*100):0}%`}}/></div><strong>{d.minutes}</strong><small>{d.label}</small></div>)}</div></section>
      </div>
    </div>
    <section className="card session-history"><div className="card-heading"><div><p className="eyebrow">YOUR LOG</p><h2>Recent focus sessions</h2></div><span className="muted-copy">{sessions.filter(s=>s.completed).length} total</span></div>{!sessions.filter(s=>s.completed).length?<div className="empty-state compact"><div className="empty-glyph">◷</div>Your completed sessions will appear here.</div>:<div className="history-list">{sessions.filter(s=>s.completed).slice().reverse().slice(0,8).map(s=><div className="history-row" key={s.id}><span className="history-icon">✓</span><div className="history-main"><strong>{D.subjects.find(x=>x.id===s.subjectId)?.name||"General study"}</strong><small>{new Date(s.completedAt).toLocaleString()}</small></div><strong>{s.durationMinutes} min</strong><span className="xp-pill">+{s.xpAwarded||10} XP</span></div>)}</div>}</section>
  </Shell>;
}
