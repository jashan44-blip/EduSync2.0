import { useState } from "react";
import { Link } from "react-router-dom";
import { Shell } from "../Shell.jsx";
import { usePage } from "../SiteLayout.jsx";
import { currentUserData, saveApp, uid } from "../core.js";
import { awardXp, consumeBadgeNotifications, getGamificationStats } from "../gamification.js";
import { flash } from "../flash.js";

const QUESTION_BANK = {
  programming: [
    { prompt: "What does a JavaScript array's `length` property return?", options: ["The index of the last item", "The number of items", "The array's memory size", "The first item"], answer: 1, explanation: "Array length is the number of elements, including empty slots." },
    { prompt: "Which SQL clause filters rows before grouping?", options: ["ORDER BY", "HAVING", "WHERE", "SELECT"], answer: 2, explanation: "WHERE filters source rows; HAVING filters grouped results." },
    { prompt: "What is the time complexity of binary search on a sorted array?", options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"], answer: 1, explanation: "Each comparison halves the remaining search interval." },
    { prompt: "Which HTML element is most appropriate for the main content of a page?", options: ["`<main>`", "`<span>`", "`<aside>`", "`<footer>`"], answer: 0, explanation: "The main element identifies the document's dominant content." },
    { prompt: "In a relational database, what does a foreign key do?", options: ["Encrypts a column", "Links records to a key in another table", "Sorts a table", "Prevents all duplicate rows"], answer: 1, explanation: "A foreign key enforces a relationship to a referenced key." },
    { prompt: "Which structure follows last-in, first-out order?", options: ["Queue", "Stack", "Tree", "Graph"], answer: 1, explanation: "A stack removes the most recently added item first." }
  ],
  math: [
    { prompt: "What is 15% of 200?", options: ["15", "25", "30", "35"], answer: 2, explanation: "0.15 × 200 = 30." },
    { prompt: "What is the slope of y = 3x + 2?", options: ["2", "3", "5", "-3"], answer: 1, explanation: "In y = mx + b, m is the slope." },
    { prompt: "What is the value of 2⁵?", options: ["10", "16", "25", "32"], answer: 3, explanation: "2 × 2 × 2 × 2 × 2 = 32." },
    { prompt: "A triangle's angles add up to:", options: ["90°", "180°", "270°", "360°"], answer: 1, explanation: "The interior angles of a Euclidean triangle total 180°." },
    { prompt: "What is the median of 3, 5, 8, 10, 14?", options: ["5", "8", "9", "10"], answer: 1, explanation: "The median is the middle value in an ordered list." },
    { prompt: "Solve: 4x = 28.", options: ["6", "7", "8", "24"], answer: 1, explanation: "Divide both sides by 4 to get x = 7." }
  ],
  science: [
    { prompt: "Which unit measures force?", options: ["Joule", "Watt", "Newton", "Pascal"], answer: 2, explanation: "The newton (N) is the SI unit of force." },
    { prompt: "What gas do plants absorb during photosynthesis?", options: ["Oxygen", "Carbon dioxide", "Nitrogen", "Hydrogen"], answer: 1, explanation: "Plants use carbon dioxide and water to make sugars and oxygen." },
    { prompt: "What is the chemical symbol for sodium?", options: ["S", "So", "Na", "N"], answer: 2, explanation: "Na comes from the Latin name natrium." },
    { prompt: "Which particle has a negative electric charge?", options: ["Proton", "Neutron", "Electron", "Nucleus"], answer: 2, explanation: "Electrons carry a negative elementary charge." },
    { prompt: "At standard atmospheric pressure, water boils at:", options: ["0°C", "50°C", "100°C", "212°C"], answer: 2, explanation: "Water's boiling point is 100°C (212°F) at 1 atmosphere." },
    { prompt: "Which cell structure contains most genetic material?", options: ["Ribosome", "Nucleus", "Cell membrane", "Golgi apparatus"], answer: 1, explanation: "In eukaryotic cells, most DNA is stored in the nucleus." }
  ],
  history: [
    { prompt: "The Magna Carta was sealed in which year?", options: ["1066", "1215", "1492", "1776"], answer: 1, explanation: "King John sealed the Magna Carta in 1215." },
    { prompt: "The Renaissance began in which European country?", options: ["France", "Italy", "Spain", "England"], answer: 1, explanation: "The Renaissance began in Italy before spreading across Europe." },
    { prompt: "Which ancient civilization built Machu Picchu?", options: ["Maya", "Aztec", "Inca", "Olmec"], answer: 2, explanation: "Machu Picchu was built by the Inca in the Andes." },
    { prompt: "The printing press associated with Johannes Gutenberg used movable type in:", options: ["15th-century Europe", "11th-century China", "18th-century France", "7th-century Rome"], answer: 0, explanation: "Gutenberg's press transformed European printing in the 15th century." },
    { prompt: "Which city was divided by a wall during the Cold War?", options: ["Vienna", "Berlin", "Prague", "Warsaw"], answer: 1, explanation: "The Berlin Wall divided East and West Berlin from 1961 to 1989." },
    { prompt: "The ancient Olympic Games originated in:", options: ["Greece", "Egypt", "Persia", "Rome"], answer: 0, explanation: "The ancient Olympic Games were held at Olympia in Greece." }
  ],
  general: [
    { prompt: "Which technique uses brief, timed study intervals followed by breaks?", options: ["Pomodoro technique", "Mind mapping", "SQ3R", "Spaced repetition"], answer: 0, explanation: "The Pomodoro technique alternates focused intervals with short breaks." },
    { prompt: "Which practice is most useful for checking what you can recall without notes?", options: ["Rereading a chapter", "Active recall", "Highlighting every paragraph", "Copying notes verbatim"], answer: 1, explanation: "Active recall strengthens retrieval by trying to produce information from memory." },
    { prompt: "Spaced repetition is designed to:", options: ["Review material at increasing intervals", "Study everything in one sitting", "Skip difficult topics", "Replace sleep"], answer: 0, explanation: "Spacing reviews over time helps combat forgetting." },
    { prompt: "When a task feels too large, a useful first step is to:", options: ["Wait for motivation", "Break it into a small next action", "Add more tasks", "Avoid making a plan"], answer: 1, explanation: "A concrete, small next action makes it easier to get started." },
    { prompt: "Which is the best way to use a practice quiz?", options: ["Check only the final score", "Review incorrect answers and why", "Guess quickly", "Repeat without feedback"], answer: 1, explanation: "Understanding errors helps target what to review next." },
    { prompt: "A realistic study goal is most helpful when it is:", options: ["Specific and measurable", "As vague as possible", "Based on someone else's schedule", "Impossible to finish"], answer: 0, explanation: "Specific, measurable goals make progress easier to plan and check." }
  ]
};

const todayKey = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
};
const subjectCategory = name => {
  const value = name.toLowerCase();
  if (/computer|program|software|database|data structure|algorithm|network|information technology|coding/.test(value)) return "programming";
  if (/math|calculus|algebra|statistic|geometry/.test(value)) return "math";
  if (/physics|chemistry|biology|science|biotech/.test(value)) return "science";
  if (/history|civilization|political science/.test(value)) return "history";
  return "general";
};
const questionSet = subjectId => {
  const D = currentUserData();
  const subject = D.subjects.find(item => item.id === subjectId);
  return QUESTION_BANK[subject ? subjectCategory(subject.name) : "general"];
};

export default function GameZone() {
  usePage("Game Zone — EduSync", "game-zone");
  const D = currentUserData();
  const [subjectId, setSubjectId] = useState("");
  const [attempt, setAttempt] = useState(null);
  const attempts = D.gameAttempts || [];
  const today = todayKey();
  const dailyAttempt = attempts.find(item => item.challengeDate === today);
  const gameXp = attempts.reduce((total, item) => total + (item.xpEarned || 0), 0);
  const level = Math.floor(gameXp / 50) + 1;
  const levelProgress = gameXp % 50;
  const bestScore = attempts.filter(item => item.total === 5).reduce((best, item) => Math.max(best, item.score || 0), 0);
  const selectedSubject = D.subjects.find(item => item.id === subjectId);

  function startGame(daily = false) {
    if (daily && dailyAttempt) return;
    const pool = questionSet(subjectId);
    const startIndex = daily ? [...today].reduce((sum, char) => sum + char.charCodeAt(0), 0) % pool.length : 0;
    const questions = daily ? [pool[startIndex]] : Array.from({ length: 5 }, (_, i) => pool[(startIndex + i) % pool.length]);
    setAttempt({
      id: uid(),
      subjectId: subjectId || null,
      subjectName: selectedSubject?.name || "General study",
      isDaily: daily,
      questions,
      index: 0,
      score: 0,
      selected: null,
      completed: false
    });
  }

  function selectAnswer(optionIndex) {
    if (!attempt || attempt.selected !== null || attempt.completed) return;
    const question = attempt.questions[attempt.index];
    setAttempt({ ...attempt, selected: optionIndex, score: attempt.score + (optionIndex === question.answer ? 1 : 0) });
  }

  function continueGame() {
    if (!attempt || attempt.selected === null) return;
    if (attempt.index < attempt.questions.length - 1) {
      setAttempt({ ...attempt, index: attempt.index + 1, selected: null });
      return;
    }

    const xpEarned = 5 + attempt.score * 2;
    const alreadySaved = D.gameAttempts.some(item => item.id === attempt.id);
    if (!alreadySaved) {
      D.gameAttempts.push({
        id: attempt.id,
        subjectId: attempt.subjectId,
        subjectName: attempt.subjectName,
        challengeDate: attempt.isDaily ? today : null,
        score: attempt.score,
        total: attempt.questions.length,
        xpEarned,
        completedAt: new Date().toISOString()
      });
      awardXp(D, `game:${attempt.id}`, xpEarned);
      getGamificationStats(D);
      const unlocked = consumeBadgeNotifications(D);
      saveApp();
      flash(`Quiz complete — ${attempt.score}/${attempt.questions.length}. +${xpEarned} XP.`, "success");
      if (unlocked.length) flash(`Achievement unlocked: ${unlocked.join(", ")}!`, "success");
    }
    setAttempt({ ...attempt, completed: true });
  }

  const activeQuestion = attempt && attempt.questions[attempt.index];
  return (
    <Shell active="games" title="Game Zone">
      <div className="focus-head">
        <div><p className="eyebrow">LEARN BY PLAYING</p><h1>Game Zone</h1><p className="muted-copy">Quick knowledge checks based on your subjects, with honest results and saved progress.</p></div>
        <Link className="btn btn-ghost btn-sm" to="/achievements.html">View achievements ↗</Link>
      </div>
      <div className="game-summary-grid">
        <div className="card game-summary"><span>🎮</span><div><small>Game level</small><strong>Level {level}</strong><div className="goal-track"><span style={{ width: `${levelProgress * 2}%` }} /></div><em>{levelProgress} / 50 game XP to next level</em></div></div>
        <div className="card game-summary"><span>⚡</span><div><small>Game XP earned</small><strong>{gameXp}</strong><em>Across {attempts.length} completed {attempts.length === 1 ? "quiz" : "quizzes"}</em></div></div>
        <div className="card game-summary"><span>🏅</span><div><small>Personal best</small><strong>{bestScore ? `${bestScore} / 5` : "—"}</strong><em>Best score in a full quiz</em></div></div>
      </div>

      <div className="game-layout">
        <section className="card game-play-card">
          {!attempt && <div className="game-intro">
            <p className="eyebrow">TODAY'S CHALLENGE</p>
            <h2>{dailyAttempt ? "Daily challenge complete" : "One question. One daily streak."}</h2>
            <p className="muted-copy">{dailyAttempt
              ? `You scored ${dailyAttempt.score}/${dailyAttempt.total} today and earned ${dailyAttempt.xpEarned} XP. You can still play regular quizzes.`
              : "Choose one daily question or play a five-question subject quiz. Only completed attempts earn XP."}</p>
            <label className="game-subject-label">Choose a subject
              <select value={subjectId} onChange={event => setSubjectId(event.target.value)}>
                <option value="">General study</option>
                {D.subjects.map(subject => <option value={subject.id} key={subject.id}>{subject.code ? `${subject.code} — ` : ""}{subject.name}</option>)}
              </select>
            </label>
            <div className="game-start-actions">
              <button className="btn btn-primary" disabled={Boolean(dailyAttempt)} onClick={() => startGame(true)}>
                {dailyAttempt ? "Daily challenge completed" : "Start daily challenge"}
              </button>
              <button className="btn btn-ghost" onClick={() => startGame(false)}>Play a 5-question quiz</button>
            </div>
          </div>}
          {attempt && !attempt.completed && activeQuestion && <div className="quiz-question">
            <div className="quiz-meta"><span>{attempt.isDaily ? "DAILY CHALLENGE" : `${attempt.subjectName.toUpperCase()} QUIZ`}</span><span>{attempt.index + 1} / {attempt.questions.length}</span></div>
            <div className="goal-track"><span style={{ width: `${((attempt.index + 1) / attempt.questions.length) * 100}%` }} /></div>
            <h2>{activeQuestion.prompt}</h2>
            <div className="quiz-options">{activeQuestion.options.map((option, index) => {
              const isSelected = attempt.selected === index;
              const answerShown = attempt.selected !== null;
              const isCorrect = index === activeQuestion.answer;
              const className = answerShown && isCorrect ? " correct" : isSelected && !isCorrect ? " incorrect" : "";
              return <button className={`quiz-option${className}`} type="button" key={option} disabled={answerShown} onClick={() => selectAnswer(index)}>
                <span>{String.fromCharCode(65 + index)}</span>{option}
              </button>;
            })}</div>
            {attempt.selected !== null && <div className={`answer-feedback${attempt.selected === activeQuestion.answer ? " right" : " wrong"}`}>
              <strong>{attempt.selected === activeQuestion.answer ? "Correct" : "Not quite"}</strong><span>{activeQuestion.explanation}</span>
            </div>}
            <div className="quiz-footer"><span>{attempt.score} correct so far</span><button className="btn btn-primary" type="button" disabled={attempt.selected === null} onClick={continueGame}>
              {attempt.index === attempt.questions.length - 1 ? "Finish quiz" : "Next question"}
            </button></div>
          </div>}
          {attempt?.completed && <div className="quiz-result">
            <span className="result-mark">{attempt.score === attempt.questions.length ? "🎉" : "✓"}</span>
            <p className="eyebrow">QUIZ COMPLETE</p><h2>{attempt.score} of {attempt.questions.length} correct</h2>
            <p className="muted-copy">Your result and XP have been saved to this account.</p>
            <button type="button" className="btn btn-primary" onClick={() => setAttempt(null)}>Play again</button>
          </div>}
        </section>

        <section className="card game-daily-card">
          <div className="card-heading"><div><p className="eyebrow">HOW PROGRESS WORKS</p><h2>Earned, not simulated</h2></div><span className="game-icon">🧩</span></div>
          <ul className="game-rules"><li>Each quiz uses a new unique attempt record.</li><li>Daily challenge XP is limited to one completed attempt per day.</li><li>Game XP is added once per saved attempt; unfinished quizzes never count.</li></ul>
          <div className="level-progress"><div><strong>Level {level}</strong><span>{levelProgress}/50 XP</span></div><div className="goal-track"><span style={{ width: `${levelProgress * 2}%` }} /></div></div>
        </section>
      </div>

      <section className="card session-history">
        <div className="card-heading"><div><p className="eyebrow">SAVED RESULTS</p><h2>Recent quiz history</h2></div><span className="muted-copy">{attempts.length} completed</span></div>
        {!attempts.length ? <div className="empty-state compact">Complete a quiz to build your personal history.</div> :
          <div className="history-list">{attempts.slice().reverse().slice(0, 8).map(item => <div className="history-row" key={item.id}>
            <span className="history-icon">✓</span><div className="history-main"><strong>{item.challengeDate ? "Daily challenge" : item.subjectName || "General study"}</strong><small>{new Date(item.completedAt).toLocaleString()}</small></div>
            <strong>{item.score}/{item.total}</strong><span className="xp-pill">+{item.xpEarned} XP</span>
          </div>)}</div>}
      </section>
    </Shell>
  );
}
