import { saveApp } from "./core.js";
const dayKey=(d=new Date())=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
function dayDiff(a,b){const [ay,am,ad]=a.split("-").map(Number),[by,bm,bd]=b.split("-").map(Number);return Math.round((Date.UTC(by,bm-1,bd)-Date.UTC(ay,am-1,ad))/86400000);}
export function getGamificationStats(D){
 const sessions=(D.focusSessions||[]).filter(s=>s.completed), dates=[...new Set(sessions.map(s=>s.date))].sort();
 const today=dayKey(), yesterday=dayKey(new Date(Date.now()-86400000));
 let current=0;
 if(dates.includes(today)||dates.includes(yesterday)){let cursor=dates.includes(today)?today:yesterday;current=1;while(dates.includes(dayKey(new Date(new Date(cursor+"T12:00:00").getTime()-86400000)))){cursor=dayKey(new Date(new Date(cursor+"T12:00:00").getTime()-86400000));current++;}}
 let best=0,run=0,prev=null;dates.forEach(d=>{run=prev&&dayDiff(prev,d)===1?run+1:1;best=Math.max(best,run);prev=d;});
 const minutes=sessions.reduce((n,s)=>n+(s.durationMinutes||0),0);
 const assignments=(D.assignments||[]).filter(a=>a.status==="completed").length;
 const badges=[
  {id:"first",name:"First Focus",icon:"🎯",description:"Complete your first focus session.",target:1,value:sessions.length},
  {id:"deep",name:"Deep Work",icon:"🧠",description:"Complete five focus sessions.",target:5,value:sessions.length},
  {id:"hour",name:"Hour of Power",icon:"⏱️",description:"Accumulate 60 focused minutes.",target:60,value:minutes},
  {id:"roll",name:"On a Roll",icon:"🔥",description:"Achieve a three-day study streak.",target:3,value:best},
  {id:"consistency",name:"Consistency Champ",icon:"🏆",description:"Achieve a seven-day best streak.",target:7,value:best},
  {id:"task",name:"Task Finisher",icon:"✅",description:"Complete five assignments.",target:5,value:assignments}
 ];
 D.unlockedBadges=D.unlockedBadges||[];
 D.newBadgeNotifications=D.newBadgeNotifications||[];
 let newlyUnlocked=false;
 badges.forEach(b=>{if(b.value>=b.target&&!D.unlockedBadges.includes(b.id)){D.unlockedBadges.push(b.id);D.newBadgeNotifications.push(b.id);newlyUnlocked=true;}});
 if(newlyUnlocked) saveApp();
 return {currentStreak:current,bestStreak:best,sessions:sessions.length,minutes,assignments,badges:badges.map(b=>({...b,unlocked:D.unlockedBadges.includes(b.id),progress:Math.min(100,Math.round(b.value/b.target*100))})),studyDays:dates};
}
export function recordFocusCompletion(D,record){
 D.focusSessions=D.focusSessions||[];
 D.focusTransactions=D.focusTransactions||[];
 if(D.focusTransactions.includes(record.id))return [];
 D.focusTransactions.push(record.id);
 awardXp(D,`focus:${record.id}`,10);
 const stats=getGamificationStats(D);
 D.bestStudyStreak=Math.max(D.bestStudyStreak||0,stats.bestStreak);
 D.recentBadge=(D.unlockedBadges||[]).slice(-1)[0]||null;
 return consumeBadgeNotifications(D);
}
export function awardXp(D,transactionId,amount){
 D.xpTransactions=D.xpTransactions||[];
 if(D.xpTransactions.includes(transactionId))return false;
 D.xpTransactions.push(transactionId);
 D.xp=(D.xp||0)+amount;
 return true;
}
export function consumeBadgeNotifications(D){
 const ids=D.newBadgeNotifications||[];
 D.newBadgeNotifications=[];
 const names={first:"First Focus",deep:"Deep Work",hour:"Hour of Power",roll:"On a Roll",consistency:"Consistency Champ",task:"Task Finisher"};
 return ids.map(id=>names[id]||id);
}
export {dayKey};
