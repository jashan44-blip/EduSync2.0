 import { Link, Navigate, Route, Routes } from "react-router-dom";
 import { GuestOnly, RequireAuth, SiteLayout, usePage } from "./site/SiteLayout.jsx";
 import { currentUser } from "./site/core.js";
import Login from "./site/pages/Login.jsx";
import Register from "./site/pages/Register.jsx";
import Dashboard from "./site/pages/Dashboard.jsx";
import Subjects from "./site/pages/Subjects.jsx";
import Assignments from "./site/pages/Assignments.jsx";
import Attendance from "./site/pages/Attendance.jsx";
import Assistant from "./site/pages/Assistant.jsx";
import Timetable from "./site/pages/Timetable.jsx";
import FocusRoom from "./site/pages/FocusRoom.jsx";
import Achievements from "./site/pages/Achievements.jsx";
import GameZone from "./site/pages/GameZone.jsx";
import AcademicPerformance from "./site/pages/AcademicPerformance.jsx";
import SingleApp from "./single/SingleApp.jsx";

function Home() {
  usePage("EduSync — Your Academic Workspace");
  if (currentUser()) return <Navigate to="/dashboard.html" replace />;

  const features = [
    ["🎯", "Focus Room", "Complete focus sessions and build a real study streak."],
    ["🏅", "Achievements", "Earn XP and unlock badges from completed activities."],
    ["🎮", "Game Zone", "Play subject-based quizzes and daily challenges."],
    ["📊", "Academic Performance", "Review saved marks, attendance, and assignments."]
  ];

  return (
    <main className="bare-page">
      <div className="blob blob-1" />
      <div className="blob blob-2" />
      <div className="auth-wrap" style={{ maxWidth: "760px" }}>
        <section className="auth-card">
          <div className="auth-brand">
            <span className="brand-mark">ES</span>
            <p className="eyebrow">YOUR ACADEMIC WORKSPACE</p>
            <h1>Make progress visible.</h1>
            <p className="muted-copy">Plan your studies, track real academic progress, and make focused learning rewarding.</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: "12px", margin: "22px 0" }}>
            {features.map(([icon, title, description]) => (
              <article className="card" key={title} style={{ padding: "15px" }}>
                <strong>{icon} {title}</strong>
                <p className="muted-copy" style={{ margin: "7px 0 0", fontSize: "12px" }}>{description}</p>
              </article>
            ))}
          </div>
          <div className="btn-row">
            <Link className="btn btn-primary" to="/login.html">Log in</Link>
            <Link className="btn btn-ghost" to="/register.html">Create account</Link>
          </div>
          <p className="muted-copy" style={{ marginTop: "18px", fontSize: "11px" }}>
            Your account and progress are stored locally on this device.
          </p>
        </section>
      </div>
    </main>
  );
}

/* The authenticated multi-page app is the primary entry point. The original
   hash-routed evaluation demo remains available at /legacy.html. */
export default function App() {
  return (
    <Routes>
      <Route path="/legacy.html" element={<SingleApp />} />

      <Route element={<SiteLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/index.html" element={<Navigate to="/" replace />} />
        <Route path="/login.html" element={<GuestOnly><Login /></GuestOnly>} />
        <Route path="/register.html" element={<GuestOnly><Register /></GuestOnly>} />
        <Route path="/dashboard.html" element={<RequireAuth><Dashboard /></RequireAuth>} />
        <Route path="/subjects.html" element={<RequireAuth><Subjects /></RequireAuth>} />
        <Route path="/assignments.html" element={<RequireAuth><Assignments /></RequireAuth>} />
        <Route path="/attendance.html" element={<RequireAuth><Attendance /></RequireAuth>} />
        <Route path="/assistant.html" element={<RequireAuth><Assistant /></RequireAuth>} />
        <Route path="/timetable.html" element={<RequireAuth><Timetable /></RequireAuth>} />
        <Route path="/focus-room.html" element={<RequireAuth><FocusRoom /></RequireAuth>} />
        <Route path="/achievements.html" element={<RequireAuth><Achievements /></RequireAuth>} />
        <Route path="/game-zone.html" element={<RequireAuth><GameZone /></RequireAuth>} />
        <Route path="/academic-performance.html" element={<RequireAuth><AcademicPerformance /></RequireAuth>} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
