# EduSync — React version

A 1:1 React (Vite + React Router) port of the original HTML/CSS/JS project.
Same look, same data, same `localStorage` keys, same URLs.

## Run

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in dist/
npm run preview
```


## Routes (same as the original files)

| URL | Original file |
|---|---|
| `/` or `/index.html` | Main app landing page; login/register leads to the authenticated workspace |
| `/legacy.html` | Original single-file evaluation demo (landing, login, register, dashboard, subjects, assignments, attendance, assistant via `#hash`) |
| `/login.html`, `/register.html` | auth pages of the multi-page site |
| `/dashboard.html`, `/subjects.html`, `/assignments.html`, `/attendance.html`, `/assistant.html`, `/timetable.html`, `/focus-room.html`, `/achievements.html`, `/game-zone.html`, `/academic-performance.html` | authenticated multi-page site |

The two apps keep separate storage (`edusync_evaluation_demo_v2` and
`edusync_site_v1`). The single-file app stores academic records per account;
new accounts start with an empty study profile, while the evaluation demo keeps
its sample data under the demo account.

Both study assistants run locally without an API key. They can answer questions
from the signed-in account's data and update attendance with commands such as
`mark CSE301 present`, `mark Algorithms absent`, or `mark Algorithms present on
2026-10-26`. A hosted AI API should only be added behind a server-side endpoint;
never put a provider secret in browser code.

## Layout

```
src/
  styles/site.css, single.css   original CSS, verbatim (each is only mounted while its app is on screen)
  lib/motion.js                 cursor glow, magnetic buttons, tilt, scroll-reveal
  lib/flash.jsx                 toast store + <FlashStack>
  site/                         multi-page site: core.js (logic), Shell.jsx, Modals.jsx, pages/*
  single/                       index.html app: store.js (logic), SingleApp.jsx
```

Business logic includes priority scoring, the attendance guardian, insights, local
assistant actions, timetable generation, and hashing; rendering uses React components.


## Focus, games, themes, and academic performance

The authenticated React Router application includes:

- **Focus Room** (`/focus-room.html`): real-time focus/break countdown, configurable durations, subject association, daily goal, seven-day focus chart, and persisted completed-session history.
- **Achievements** (`/achievements.html`): XP summary, current/best study streak, condition-based badges, weekly milestones, and personal records.
- **Game Zone** (`/game-zone.html`): subject-matched educational multiple-choice quizzes, answer explanations, one daily challenge per day, score history, levels, personal bests, and idempotent XP rewards.
- **Academic Performance** (`/academic-performance.html`): actual saved subject marks, attendance, assignment completion, filters, and dated mark snapshots. Use “Record current marks” to save a dated snapshot from the marks currently entered on Subjects.
- **Light/dark mode**: the preference is saved in `localStorage` and applied before the app renders. Dashboard preview tiles switch the live theme.
- **Dashboard**: quick links and summaries for focus time, daily goal, streak, XP, achievements, game progress, and academic marks.

Focus sessions, XP transaction IDs, badges, mark snapshots, and game attempts are stored additively in the existing `edusync_site_v1` localStorage data model under the signed-in user's record. Existing accounts receive missing fields lazily without replacing their academic data. Completed focus sessions award 10 XP, completed assignments award 20 XP, and finished quizzes award 5 XP plus 2 XP per correct answer. XP is recorded once per activity transaction. Attendance continues to award XP according to the existing project rules.

The current subject mark field stores one value rather than a historical series. The performance page shows an empty trend state until the user records dated snapshots; it does not invent past marks. Quiz questions are bundled educational content selected by subject-name category, with a study-skills fallback for uncategorized subjects.

The original hash-routed evaluation demo is available at `/legacy.html` and retains its separate `edusync_evaluation_demo_v2` store and feature set. The primary authenticated multi-page app uses `edusync_site_v1`; the two stores are intentionally not merged.

### Run locally

```bash
npm install
npm run dev
```

For a production build, run `npm run build`.

Run `npm run build` to validate and create the production bundle. There is no configured test or lint script in this project.

## Verification and limitations

- `npm run build` completes successfully.
- Browser smoke checks covered all authenticated routes, light/dark persistence after reload, the mobile drawer, desktop sidebar alignment, quiz completion and daily replay protection, assignment completion, a genuinely completed one-minute focus session, and marks snapshot rendering.
- At a 390px mobile viewport, the authenticated routes tested without horizontal overflow. The desktop sidebar remained fixed at the left edge and full viewport height.
- There is no automated unit-test or lint command in `package.json`.
- Records are local to the browser and are not synchronized between devices. The existing browser-only authentication is for project demonstration, not production security.
- Subject records currently hold one current mark. Trend charts need snapshots recorded on different dates; no past marks are inferred.
- Game questions come from a small bundled educational question bank selected by subject category. They are playable and scored, but are not generated from course materials.

## Main implementation files

- `src/site/Shell.jsx`, `src/styles/site.css`: fixed desktop sidebar, accessible mobile drawer, shared theme toggle, and responsive styling.
- `src/site/theme.js`, `index.html`, `src/styles/single.css`: persistent light/dark preference and pre-render theme initialization for both existing app surfaces.
- `src/site/gamification.js`, `src/site/core.js`: streaks, badge notifications, activity-based XP transactions, and additive local data defaults.
- `src/site/pages/GameZone.jsx`, `src/site/pages/AcademicPerformance.jsx`: playable quizzes and actual-record academic charts.
- `src/site/pages/FocusRoom.jsx`, `src/site/pages/Achievements.jsx`, `src/site/pages/Dashboard.jsx`: focus, achievements, dashboard summaries, and theme previews.
